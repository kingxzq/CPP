#include "RBTree.h"
using namespace std;

int main()
{
    RBTree<int> rb;
    rb.Insert(13);
    rb.Insert(8);
    rb.Insert(17);
    rb.Insert(1);
    rb.Insert(11);
    rb.Insert(15);
    rb.Insert(25);
    rb.Insert(6);
    rb.Insert(22);
    rb.Insert(27);

    rb.IsValidRBTRee();
    rb.InOrder();
    rb.Find(25);
    rb.Find(10);
    rb.LeftMost();
    rb.RightMost();
    rb.GetRoot();
    return 0;
}