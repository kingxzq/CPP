#include "RBTree.h"

int main()
{
    RBTree<int> rb;
    rb.Insert(13);
    rb.Insert(8);
    rb.Insert(17);
    rb.Insert(1);
    rb.Insert(11);
    rb.Insert(15);
    rb.Insert(25);
    rb.Insert(6);
    rb.Insert(22);
    rb.Insert(27);

    //rb.IsValidRBTRee();
    //rb.InOrder();
    for (auto& x:rb)
        cout << x << " ";
    cout << endl;
    RBTree<int>::iterator it1 = rb.Find(25);
    RBTree<int>::iterator it2 = rb.Find(10);

    if (it1 != rb.end()) cout << "25 ����" << endl;
    else cout << "25 ������" << endl;
    if (it2 != rb.end()) cout << "10 ����" << endl;
    cout << "10 ������" << endl;

    cout << rb.Size() << endl;
    rb.Clear();
    cout << rb.Size() << endl;
    //rb.LeftMost();
    //rb.RightMost();
    //rb.GetRoot();
    return 0;
}