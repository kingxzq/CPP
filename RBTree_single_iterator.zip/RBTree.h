#pragma once
#include <iostream>
#include <utility> 
#include <assert.h>
using namespace std;

enum Colour
{
	RED,
	BLACK
};

template<class T>
struct RBTreeNode
{
	RBTreeNode<T>* _left;
	RBTreeNode<T>* _right;
	RBTreeNode<T>* _parent;

	T _data;
	Colour _col;

	RBTreeNode(const T& data)
		:_left(nullptr)
		, _right(nullptr)
		, _parent(nullptr)
		, _data(data)
	{}
};

template<class T, class Ref, class Ptr>
struct __RBTreeIterator
{
    typedef RBTreeNode<T> Node;
    typedef __RBTreeIterator<T, Ref, Ptr> Self;

    __RBTreeIterator(Node* node)
        :_node(node)
    {}

    Ref operator*()
    {
        return _node->_data;
    }

    Ptr operator->()
    {
        return *_node->_data;
    }

    bool operator!=(const Self& s) const
    {
        return _node != s._node;
    }

    bool operator==(const Self& s) const
    {
        return _node == s._node;
    }

    Self& operator++()
    {
        if (_node->_right)
        {
            // ��һ������������������ڵ�
            Node* left = _node->_right;
            while (left->_left)
            {
                left = left->_left;
            }

            _node = left;
        }
        else
        {
            // ���������溢�Ӳ������ȵ��ҵ��Ǹ�
            Node* parent = _node->_parent;
            Node* cur = _node;
            while (parent && cur == parent->_right)
            {
                cur = cur->_parent;
                parent = parent->_parent;
            }

            _node = parent;
        }

        return *this;
    }

    Self operator++(int) {
        Self tmp = *this;
        ++*this;
        return tmp;
    }

    Self& operator--()
    {
        if (_node->_left)
        {
            // ��һ���������������ҽڵ�
            Node* right = _node->_left;
            while (right->_right)
            {
                right = right->_right;
            }

            _node = right;
        }
        else
        {
            // ���Ӳ��Ǹ��׵�����Ǹ�����
            Node* parent = _node->_parent;
            Node* cur = _node;
            while (parent && cur == parent->_left)
            {
                cur = cur->_parent;
                parent = parent->_parent;
            }

            _node = parent;
        }

        return *this;
    }

    Self operator--(int) {
        Self tmp = *this;
        -- *this;
        return tmp;
    }
private:
    Node* _node;
};

template<class T>
struct RBTree
{
	typedef RBTreeNode<T> Node;
public:
    typedef __RBTreeIterator<T,T&,T*> iterator;
	// �ں�����в���ֵΪdata�Ľڵ㣬����ɹ�����true�����򷵻�false
	// ע�⣺Ϊ�˼����������ʵ�ֺ�������洢�ظ���Ԫ��
    iterator begin() 
    {
        Node* left = _root;
        while (left && left->_left)
        {
            left = left->_left;
        }

        return iterator(left);
    }

    iterator end()
    {
        return iterator(nullptr);
    }

    pair<iterator, bool> Insert(const T& data) {
        if (_root == nullptr)//Ϊ��ֱ�Ӳ���
        {
            _root = new Node(data);
            _root->_col = BLACK;
            ++size;
            return make_pair(iterator(_root), true);;
        }

        Node* parent = nullptr;
        Node* cur = _root;
        while (cur)//ͬ�����������ҵ�����λ��
        {
            if (cur->_data < data)
            {
                parent = cur;
                cur = cur->_right;
            }
            else if (cur->_data > data)
            {
                parent = cur;
                cur = cur->_left;
            }
            else
            {
                return make_pair(iterator(cur), false);
            }
        }

        cur = new Node(data);
        Node* newnode = cur;
        cur->_col = RED;//�²���ڵ㼴Ϊ��ڵ�

        if (parent->_data < data)//ͬ������������ֱ�Ӳ���
        {
            parent->_right = cur;
        }
        else
        {
            parent->_left = cur;
        }

        cur->_parent = parent;//�����²���ڵ�ĸ�ָ��

        while (parent && parent->_col == RED)
        {
            Node* grandfater = parent->_parent;
            assert(grandfater);
            assert(grandfater->_col == BLACK);
            if (parent == grandfater->_left)
            {
                Node* uncle = grandfater->_right;
                // ���һ : uncle������Ϊ�죬��ɫ+�������ϴ���
                if (uncle && uncle->_col == RED)
                {
                    parent->_col = uncle->_col = BLACK;
                    grandfater->_col = RED;
                    // �������ϴ���
                    cur = grandfater;
                    parent = cur->_parent;
                }// �����+����uncle������ + ������Ϊ��
                else
                {
                    // ��������ҵ���+��ɫ
                    if (cur == parent->_left)
                    {
                        RotateR(grandfater);
                        parent->_col = BLACK;
                        grandfater->_col = RED;
                    }
                    else
                    {
                        // ����������ҵ���+��ɫ
                        RotateL(parent);
                        RotateR(grandfater);
                        cur->_col = BLACK;
                        grandfater->_col = RED;
                    }

                    break;
                }
            }
            else // (parent == grandfater->_right)
            {
                Node* uncle = grandfater->_left;
                // ���һ
                if (uncle && uncle->_col == RED)
                {
                    parent->_col = uncle->_col = BLACK;
                    grandfater->_col = RED;
                    // �������ϴ���
                    cur = grandfater;
                    parent = cur->_parent;
                }
                else
                {
                    // �����������+��ɫ
                    if (cur == parent->_right)
                    {
                        RotateL(grandfater);
                        parent->_col = BLACK;
                        grandfater->_col = RED;
                    }
                    else
                    {
                        // �������������+��ɫ
                        RotateR(parent);
                        RotateL(grandfater);
                        cur->_col = BLACK;
                        grandfater->_col = RED;
                    }

                    break;
                }
            }

        }

        _root->_col = BLACK;
        ++size;
        return make_pair(iterator(newnode), true);
	}

	// ����������Ƿ����ֵΪdata�Ľڵ㣬���ڷ��ظýڵ�ĵ�ַ�����򷵻�nullptr
    iterator Find(const T& data) {
        Node* node = _Find(_root, data);
        if (node) return iterator(node);
        else return end();
    }

	// ��ȡ����������ڵ�
    Node* LeftMost() {
        Node* tmp = _LeftMost(_root);
        if (tmp) cout << "�����ڵ��� " << tmp->_data << endl;
        else cout << "��Ϊ��" << endl;
        return tmp;
    }

	// ��ȡ��������Ҳ�ڵ�
    Node* RightMost() {
        Node* tmp = _RightMost(_root);
        if (tmp) cout << "���Ҳ�ڵ��� " << tmp->_data << endl;
        else cout << "��Ϊ��" << endl;
        return tmp;
    }

	// ��������Ƿ�Ϊ��Ч�ĺ������ע�⣺���ڲ���Ҫ����_IsValidRBTRee�������
    bool IsValidRBTRee() {
        if (_root == nullptr)
        {
            return true;
        }

        if (_root->_col == RED)//�����ڵ��Ƿ�Ϊ��
        {
            cout << "���ڵ㲻�Ǻ�ɫ" << endl;
            return false;
        }

        // ��ɫ�ڵ�������׼ֵ
        int benchmark = 0;
        bool tmp= _IsValidRBTRee(_root, 0, benchmark);
        cout << "�����Ϊ��Ч�ĺ����" << endl;
        return tmp;
    }

    void InOrder()
    {
        _InOrder(_root);
    }

    Node*& GetRoot() {
        cout << "���ڵ���" << _root->_data << endl;
        return _root;
    }

    // ������Ƿ�Ϊ�գ��Ƿ���true�����򷵻�false
    bool Empty()const
    {
        if (size) return true;
        else return false;
    }
    // ���غ��������Ч�ڵ�ĸ���
    size_t Size()const
    {
        return size;
    }
    // ��������е���Ч�ڵ�ɾ����ע�⣺ɾ��������Ч�ڵ㣬��ɾ��ͷ���
    void Clear() {
        _Destroy(_root);
        _root = nullptr;
        size = 0;
    }
private:
    void _Destroy(Node*& root) {
        if (root == nullptr) {
            return;
        }

        _Destroy(root->_left);
        _Destroy(root->_right);

        root->_left = nullptr;
        root->_right = nullptr;
        root->_parent = nullptr;
        delete root;
    }
    void _InOrder(Node* root)
    {
        if (root == nullptr)
        {
            return;
        }

        _InOrder(root->_left);
        cout << root->_data << endl;
        _InOrder(root->_right);
    }

    bool _IsValidRBTRee(Node* root, int blackNum, int& benchmark)
    {
        if (root == nullptr)
        {
            if (benchmark == 0)
            {
                benchmark = blackNum;
                return true;
            }

            if (blackNum != benchmark)
            {
                cout << "ĳ����ɫ�ڵ�����������" << endl;
                return false;
            }
            else
            {
                return true;
            }
        }

        if (root->_col == BLACK)
        {
            ++blackNum;
        }

        if (root->_col == RED && root->_parent->_col == RED)
        {
            cout << "���������ĺ�ɫ�ڵ�" << endl;
            return false;
        }

        return _IsValidRBTRee(root->_left, blackNum, benchmark)
            && _IsValidRBTRee(root->_right, blackNum, benchmark);
    }

	// ����
    void RotateL(Node* parent)
    {
        Node* subR = parent->_right;
        Node* subRL = subR->_left;

        parent->_right = subRL;
        if (subRL)
            subRL->_parent = parent;

        Node* ppNode = parent->_parent;

        subR->_left = parent;
        parent->_parent = subR;

        if (_root == parent)
        {
            _root = subR;
            subR->_parent = nullptr;
        }
        else
        {
            if (ppNode->_left == parent)
            {
                ppNode->_left = subR;
            }
            else
            {
                ppNode->_right = subR;
            }

            subR->_parent = ppNode;
        }
    }

	// �ҵ���
    void RotateR(Node* parent)
    {
        Node* subL = parent->_left;
        Node* subLR = subL->_right;

        parent->_left = subLR;
        if (subLR)
        {
            subLR->_parent = parent;
        }

        Node* ppNode = parent->_parent;

        subL->_right = parent;
        parent->_parent = subL;

        if (_root == parent)
        {
            _root = subL;
            subL->_parent = nullptr;
        }
        else
        {
            if (ppNode->_left == parent)
            {
                ppNode->_left = subL;
            }
            else
            {
                ppNode->_right = subL;
            }

            subL->_parent = ppNode;
        }

    }

    Node* _Find(Node*& Root, const T& data) {
        if (!Root) return nullptr;
        if (data == Root->_data) return Root;
        else if (data > Root->_data) return _Find(Root->_right, data);
        else return _Find(Root->_left, data);
    }

    Node* _LeftMost(Node*& Root) {
        if (!Root) return nullptr;
        if (!Root->_left) return Root;
        return _LeftMost(Root->_left);
    }

    Node* _RightMost(Node*& Root) {
        if (!Root) return nullptr;
        if (!Root->_right) return Root;
        return _RightMost(Root->_right);
    }
	// Ϊ�˲��������������ȡ���ڵ�
private:
	Node* _root = nullptr;
    size_t size = 0;
};


